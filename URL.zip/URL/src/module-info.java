/**
 * 
 */
/**
 * @author dell
 *
 */
module URL {
	requires json.simple;
}