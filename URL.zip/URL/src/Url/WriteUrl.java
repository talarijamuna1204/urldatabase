package Url;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class WriteUrl {

	public static void main(String[] args) throws IOException, ParseException {
	    
		int count = 0;

		Scanner myObj = new Scanner(System.in);  // Create a Scanner object

		    boolean TRUE = true;
			while (TRUE) {
			    System.out.println("ENTER COMMAND:");
			    String urlname = myObj.nextLine();		    	
		   
		    switch (urlname) {
		    case "storeurl":
		        String storeurl = myObj.nextLine();
		        storeUrl(storeurl);
		      break;
		    case "get":
		    	   String counturl = myObj.nextLine();
			    	
			 		  JSONParser jsonP1 = new JSONParser();  
					  FileReader reader1 = new FileReader("urls.json");
					   //Read JSON File
					   Object obj1 = jsonP1.parse(reader1);
					   JSONArray empList1 = (JSONArray) obj1;
				

					   empList1.forEach(emp1 -> {
						try {
							countGet((JSONObject)emp1);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					});

		      break;
		    case "count":
		    	   String countur2 = myObj.nextLine();
		    	
			 		  JSONParser jsonP2 = new JSONParser();  
					  FileReader reader2 = new FileReader("urls.json");
					   //Read JSON File
					   Object obj2 = jsonP2.parse(reader2);
					   JSONArray empList2 = (JSONArray) obj2;
				

					   empList2.forEach(emp2 -> counts((JSONObject)emp2));

		      break;
		    case "list":
		 		  JSONParser jsonP = new JSONParser();  
				  FileReader reader = new FileReader("urls.json");
				   Object obj = jsonP.parse(reader);
				   JSONArray empList = (JSONArray) obj;
				   empList.forEach(emp -> parseEmpObj((JSONObject)emp));
		      break;
		    case "exit":
		        System.out.println("EXITED");
		        System.exit(0);

		      break;

		  }

		   
		    }
				
		

	}

	 private static void storeUrl(String storeurl) throws IOException, ParseException {
	        JSONParser jsonParser1 = new JSONParser();
            Object obj = jsonParser1.parse(new FileReader("urls.json"));
            JSONArray jsonArray1 = (JSONArray)obj;


			JSONObject url1= new JSONObject();
			url1.put("id",1);
			url1.put("url",storeurl);
			url1.put("count", '0');
			
			JSONObject urlObj=new JSONObject();
			urlObj.put("key", url1);	
			
            jsonArray1.add(urlObj);

			
			FileWriter file=new FileWriter("urls.json",false);
			file.write(jsonArray1.toJSONString());
			file.flush();
           //file.close();

	 }
	 
	 
	 private static void countGet(JSONObject emp12) throws IOException {
		  JSONObject urlObj2 = (JSONObject) emp12.get("key");

		    int count = Integer.parseInt(urlObj2.get("count").toString());
			JSONObject url= new JSONObject();
	        count++;
			url.put("count", count);
			  JSONObject urlObj3 = (JSONObject) emp12.get("key");
			  System.out.println("counted by 1: " + count);
			
			 
			 JSONObject urlObj=new JSONObject();
			urlObj.put("key", url);	
			
			JSONArray urlList= new JSONArray();
			urlList.add(urlObj);
			
			FileWriter file=new FileWriter("urls.json",false);
			file.write(urlList.toJSONString());
			file.flush();	
		 
	
	 }
	 
	 public static void counts(JSONObject emp2){
		  JSONObject empObj2 = (JSONObject) emp2.get("key");

		    int count = Integer.parseInt(empObj2.get("count").toString());

			  System.out.println("Count: " + count);
	
	 }
	
	 
	
	 private static void parseEmpObj(JSONObject emp) {
		  JSONObject empObj = (JSONObject) emp.get("key");
		  String url = (String) empObj.get("url");
		  int id = Integer.parseInt(empObj.get("id").toString());
		  int count = Integer.parseInt(empObj.get("count").toString());
		  System.out.println("Url: " + url);
		  System.out.println("id: " + id);
		  System.out.println("Count: " + count);
	 }
	
	
	
	
	
	
}
